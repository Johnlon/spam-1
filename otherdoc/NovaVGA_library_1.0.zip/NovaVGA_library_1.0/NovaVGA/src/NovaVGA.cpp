/**
 *     __  ____                 _   __                
 *    /  |/  (_)_____________  / | / /___ _   ______ _
 *   / /|_/ / / ___/ ___/ __ \/  |/ / __ \ | / / __ `/
 *  / /  / / / /__/ /  / /_/ / /|  / /_/ / |/ / /_/ / 
 * /_/  /_/_/\___/_/   \____/_/ |_/\____/|___/\__,_/  
 *                                                  
 * NovaVGA Arduino Library
 * v 1.0 (10/20/2015)
 * Copyright (c) 2015 MicroNova, LLC
 * www.micro-nova.com
 */

#include "Arduino.h"
#include "SPI.h"
#include "NovaVGA.h"
#include "include/font.h"

NovaVGAClass NovaVGA;

/**
 * The chip select pin used with SPI
 */
uint8_t NovaVGAClass::cspin_;

/**
 * Initialize the NovaVGA
 * cspin: The chip select pin used
 */
void NovaVGAClass::init(uint8_t cspin)
{
	// Initialize SPI
  cspin_ = cspin;
	pinMode(cspin, OUTPUT);
  digitalWrite(cspin, HIGH);
	SPI.begin();
}

/**
 * Write a pixel to the specified coordinate
 * Top-left is (0,0), bottom-right is (SCREEN_WIDTH,SCREEN_HEIGHT)
 * x: column
 * y: row
 * color: color to draw the pixel
 */
void NovaVGAClass::writePixel(uint8_t x, uint8_t y, uint8_t color)
{
  // Gain control of SPI bus with max 8 MHz clock
  SPI.beginTransaction(SPISettings(8000000, MSBFIRST, SPI_MODE1));
  digitalWrite(cspin_, LOW);      // Assert chip select
  SPI.transfer(color);            // Send in the coordinates and color via SPI
  SPI.transfer(x);
  SPI.transfer(y);
  digitalWrite(cspin_, HIGH);     // Deassert chip select
  SPI.endTransaction();           // Release the SPI bus
}

/**
 * Write a pixel to the specified point
 * Top-left is (0,0), bottom-right is (SCREEN_WIDTH,SCREEN_HEIGHT)
 * p: point to draw at
 * color: color to draw the pixel
 */
void NovaVGAClass::writePixel(Point p, uint8_t color)
{
  // Gain control of SPI bus with max 8 MHz clock
  SPI.beginTransaction(SPISettings(8000000, MSBFIRST, SPI_MODE1));
  digitalWrite(cspin_, LOW);      // Assert chip select
  SPI.transfer(color);            // Send in the coordinates and color via SPI
  SPI.transfer(p.x);
  SPI.transfer(p.y);
  digitalWrite(cspin_, HIGH);     // Deassert chip select
  SPI.endTransaction();           // Release the SPI bus
}

/**
 * Fill the entire screen with a given color
 * color: color to draw the screen
 */
void NovaVGAClass::fillScreen(uint8_t color)
{
	int w, h;
	for (h = 0; h < SCREEN_HEIGHT; h++)
		for (w = 0; w < SCREEN_WIDTH; w++)
			writePixel(w, h, color);
}

/**
 * Draws a filled rectangle at the specified coordinates
 * x: left coordinate
 * y: top coordinate
 * w: width of the rectangle
 * h: height of the rectangle
 * color: color to draw the rectangle
 */
void NovaVGAClass::fillRect(uint8_t x, uint8_t y, uint8_t w, uint8_t h, uint8_t color)
{
	for (uint8_t i = 0; i < h; i++)
		for (uint8_t j = 0; j < w; j++)
			writePixel(x+j, y+i, color);
}

/**
 * Draws a filled rectangle at the specified coordinates
 * r: The rectangle coordinates
 * color: color to draw the rectangle
 */
void NovaVGAClass::fillRect(Rect r, uint8_t color)
{
	for (uint8_t i = 0; i < r.height; i++)
		for (uint8_t j = 0; j < r.width; j++)
			writePixel(r.left+j, r.top+i, color);
}

/**
 * Draws a letter at the specified location with a given color
 * bitmap: An 8-element byte array
 * x: left coordinate
 * y: top coordinate
 * color: color to display character as
 */
void NovaVGAClass::drawChar(const char *bitmap, uint8_t x, uint8_t y, uint8_t color)
{
	int h, w, set;
	for (h = 0; h < CHAR_HEIGHT; h++)
	{
        for (w = 0; w < CHAR_WIDTH; w++)
        {
        	set = bitmap[h] & (1 << w);
        	if (set) writePixel(x + w, y + h, color);
        }
	}
}

/**
 * Draws a letter at the specified location with a given color
 * ch: character to draw
 * p: point to draw at
 * color: color to display character as
 */
void NovaVGAClass::drawChar(char ch, Point p, uint8_t color)
{
  drawChar(font8x8[ch], p.x, p.y, color);
}

/**
 * Draws a letter at the specified location with a given color
 * ch: character to draw
 * x: left coordinate
 * y: top coordinate
 * color: color to display character as
 */
void NovaVGAClass::drawChar(char ch, uint8_t x, uint8_t y, uint8_t color)
{
	drawChar(font8x8[ch], x, y, color);
}

/**
 * Draws a string at the specified location with a given color
 * Newline characters (\n) are supported
 * str: The string to draw
 * x: left coordinate
 * y: top coordinate
 * color: color to display string as
 */
void NovaVGAClass::drawString(const String str, uint8_t x, uint8_t y, uint8_t color)
{
	char ch;
	int row = y;
	int col = x;
	for (int i = 0; i < str.length(); i++)
	{
		ch = str.charAt(i);
		if (ch == '\n')
		{
			col = x;
			row += 8;
		}
		else
		{
			drawChar(font8x8[ch], col, row, color);
			col += 8;
		}
	}
}

/**
 * Draws a string at the specified location with a given color
 * Newline characters (\n) are supported
 * str: The string to draw
 * p: point to draw at
 * color: color to display string as
 */
void NovaVGAClass::drawString(const String str, Point p, uint8_t color)
{
	char ch;
	int row = p.y;
	int col = p.x;
	for (int i = 0; i < str.length(); i++)
	{
		ch = str.charAt(i);
		if (ch == '\n')
		{
			col = p.x;
			row += 8;
		}
		else
		{
			drawChar(font8x8[ch], col, row, color);
			col += 8;
		}
	}
}
