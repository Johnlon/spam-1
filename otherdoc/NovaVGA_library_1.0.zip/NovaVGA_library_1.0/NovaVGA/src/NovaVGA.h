/**
 * NovaVGA.h - Library for the MicroNova NovaVGA shield
 * Copyright (C) 2015 by MicroNova LLC
 */
#ifndef _NOVAVGA_H
#define _NOVAVGA_H

#include "Arduino.h"

struct Point
{
  char x;
  char y;
  
  Point(const char x=0, const char y=0)
  {
  	this->x = x;
  	this->y = y;
  }

  // assignment operator
  Point& operator=(const Point& p)
  {
    x = p.x;
    y = p.y;
    return *this;
  }

  // equality comparison
  bool operator==(const Point& p) const
  {
    return (x == p.x && y == p.y);
  }

  // component wise addition
  Point operator+(const Point& p) const
  {
  	return Point(p.x + x, p.y + y);
  }

  // component wise subtraction
  Point operator-(const Point& p) const
  {
    return Point(p.x - x, p.y - y);
  }
};

struct Rect
{
  char top;
  char left;
  char width;
  char height;
  
  Rect(const char x=0, const char y=0, const char w=0, const char h=0)
  {
  	top = x;
  	left = y;
  	width = w;
  	height = h;
  }

  // assignment operator
  Rect& operator=(const Rect& r)
  {
    top = r.top;
    left = r.left;
    width = r.width;
    height = r.height;
    return *this;
  }

  // equality comparison
  bool operator==(const Rect& r) const
  {
    return (top == r.top &&
    		left == r.left &&
    		width == r.width &&
    		height == r.height);
  }

  // component wise addition
  Rect operator+(const Rect& r) const
  {
    return Rect(r.top + top,
				r.left + left,
				r.width + width,
				r.height + height);
  }

  // component wise subtraction
  Rect operator-(const Rect& r) const
  {
    return Rect(r.top - top,
				r.left - left,
				r.width - width,
				r.height - height);
  }
};

class NovaVGAClass
{
	public:
		static const uint8_t SCREEN_WIDTH  = 160;
		static const uint8_t SCREEN_HEIGHT = 120;
    static const uint8_t CHAR_WIDTH    = 8;
    static const uint8_t CHAR_HEIGHT   = 8;

		static void init(uint8_t cspin);
		static void writePixel(uint8_t x, uint8_t y, uint8_t color);
    static void writePixel(Point p, uint8_t color);
		static void fillScreen(uint8_t color);
		static void fillRect(uint8_t x, uint8_t y, uint8_t w, uint8_t h, uint8_t color);
    static void fillRect(Rect r, uint8_t color);
    static void drawChar(char ch, uint8_t x, uint8_t y, uint8_t color);
    static void drawChar(char ch, Point p, uint8_t color);
		static void drawString(const String str, uint8_t x, uint8_t y, uint8_t color);
    static void drawString(const String str, Point p, uint8_t color);
    
    // CGA Colors
    static const uint8_t Black        = 0b000000;
    static const uint8_t Blue         = 0b000010;
    static const uint8_t Green        = 0b001000;
    static const uint8_t Cyan         = 0b001010;
    static const uint8_t Red          = 0b100000;
    static const uint8_t Magenta      = 0b100010;
    static const uint8_t Brown        = 0b100100;
    static const uint8_t LightGray    = 0b101010;
    static const uint8_t Gray         = 0b010101;
    static const uint8_t LightBlue    = 0b010111;
    static const uint8_t LightGreen   = 0b011101;
    static const uint8_t LightCyan    = 0b011111;
    static const uint8_t LightRed     = 0b110101;
    static const uint8_t LightMagenta = 0b110111;
    static const uint8_t Yellow       = 0b111101;
    static const uint8_t White        = 0b111111;
    
    // Other colors
    static const uint8_t Orange       = 0b110100;
    static const uint8_t None         = 0xFF;
    
	private:
    static uint8_t cspin_;
  
		static void drawChar(const char *bitmap, uint8_t x, uint8_t y, uint8_t color);
};

extern NovaVGAClass NovaVGA;

#endif //_NOVAVGA_H