     __  ____                 _   __                
    /  |/  (_)_____________  / | / /___ _   ______ _
   / /|_/ / / ___/ ___/ __ \/  |/ / __ \ | / / __ `/
  / /  / / / /__/ /  / /_/ / /|  / /_/ / |/ / /_/ / 
 /_/  /_/_/\___/_/   \____/_/ |_/\____/|___/\__,_/  
                                                  
 NovaVGA Arduino Library
 v 1.0 (10/20/2015)
 Copyright (c) 2015 MicroNova, LLC
 www.micro-nova.com

 This library communicates with a NovaVGA graphics shield for the Arduino.
 A hardware SPI channel & chip select pin are used.